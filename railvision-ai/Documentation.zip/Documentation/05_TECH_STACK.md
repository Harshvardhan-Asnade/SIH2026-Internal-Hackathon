# Complete Technology Stack

| Technology | Version | Purpose | Usage Location | Why it was chosen |
|---|---|---|---|---|
| **Python** | 3.13 | Primary Backend Language | `backend/` | Required for PyTorch, OpenCV, and AI model compatibility. |
| **FastAPI** | 0.115+ | REST API Server | `backend/app/main.py` | Built-in async support prevents the AI loops from blocking API requests. |
| **Ultralytics (YOLO)** | 8.x | Object Detection | `backend/app/ai/person/module.py` | Industry standard for real-time bounding box regression. |
| **Hugging Face Transformers** | Latest | LLM Execution | `backend/app/services/llm_service.py` | Allows running Qwen models entirely offline for security. |
| **Next.js** | 16.3.0 | Web Application Framework | `/` | Server-Side Rendering (SSR) and seamless App Router architecture. |
| **React** | 19.2.8 | UI Components | `/src` | Declarative UI structure. |
| **Zustand** | 5.0.14 | Global State Manager | `/src/store` | Optimized with `useShallow` to prevent heavy dashboard re-renders. |
| **Tailwind CSS** | 4.x | Styling | `/src/components` | Rapid, consistent utility-based styling. |
| **GSAP & Framer Motion** | Latest | Animations | `/src/components` | Provides smooth, cinematic transitions across complex analytic charts. |
| **OpenCV (`opencv-python`)** | Latest | Video Decoding / Rendering | `backend/app/services/video_service.py` | Fastest CPU-based video frame reading and HUD drawing. |

### Note on Hardware Acceleration
The backend checks `torch.backends.mps.is_available()` (Apple Silicon) and `torch.cuda.is_available()` (NVIDIA) to automatically route matrix math to the fastest available hardware.
