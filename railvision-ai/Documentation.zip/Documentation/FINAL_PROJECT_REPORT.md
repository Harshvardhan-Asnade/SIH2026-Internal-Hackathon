# Final Project Report: RailVision AI (SIH1349)

## 1. Executive Summary
RailVision AI upgrades legacy railway CCTV into a proactive smart surveillance system. It merges state-of-the-art computer vision (YOLO) with local Large Language Models (Qwen) to automate crowd management, crime prevention, and staff monitoring.

## 2. Problem Statement
Indian Railway stations handle massive daily footfall. Existing CCTV systems require human operators to monitor hundreds of screens, resulting in delayed responses to crowd surges and crimes. 

## 3. SIH Alignment & Implementation Status

| SIH Requirement | RailVision Feature | Implementation Status | Evidence in Code |
|---|---|---|---|
| **Crowd Management** | Density Heatmaps | [IMPLEMENTED] | `app/ai/crowd/module.py` |
| **Crime Prevention** | Loitering & Intrusion | [IMPLEMENTED] | `app/ai/crime/module.py` |
| **Work Monitoring** | Staff Detection (PPE) | [PARTIALLY IMPLEMENTED] | `app/ai/worker/module.py` uses YOLO; full FaceDB is planned. |
| **Cleanliness** | Litter/Spill detection | [PLANNED] | Not integrated into current FastAPI engine. |

## 4. Key Architectural Decisions
- **Decoupled Architecture**: Next.js Frontend + FastAPI backend.
- **Asynchronous AI**: ThreadPoolExecutors ensure video processing does not freeze the API.
- **Context Builder**: Raw detections are converted into semantic JSON (`timeline.json`) before being passed to Qwen. This prevents context-window overflow and hallucinations.

## 5. Security & Privacy
Because Qwen and YOLO are executed locally via PyTorch and Transformers, raw video frames and intelligence reports never leave the local intranet, ensuring strict compliance with railway privacy standards.

## 6. Future Scope
- Multi-camera zone stitching.
- Live RTSP streaming directly from IP cameras (currently processes uploaded MP4s).
- Full integration of the vector database (InsightFace) for individual worker facial recognition tracking.
